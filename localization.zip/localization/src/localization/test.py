import numpy as np


particles = np.random.normal([0,0,0], 1, size = (200,3))
print(particles)
